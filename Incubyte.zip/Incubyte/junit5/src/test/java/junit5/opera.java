package junit5;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
@TestInstance(Lifecycle.PER_CLASS)
class opera {
	Operations ob;
	@BeforeAll
	 void beforall()
	{
	System.out.println("started");	
	}
	@AfterAll
	 void afterall()
	{
	System.out.println("endup");	
	}
 @BeforeEach
 void beforeAll()
 {
	 ob=new Operations();
 }
 @AfterEach
 void msg()
 {
	System.out.println("ended");
 }
 
	@Test
	void testadd() {
		
		int ac=ob.add(5, 5);
		int exp=10;
		assertEquals(ac,exp,"addition is failed");
	}
	@Test
	void testsub() {
		
		int ac=ob.sub(5, 5);
		int exp=0;
		assertEquals(ac,exp,"subtraction is failed");
	}
	@Test
	void testmul() {
		
		int ac=ob.add(5, 5);
		int exp=10;
		assertEquals(ac,exp,"multiplication is failed");
	}
	@Test
	void testdiv() {
		
		int ac=ob.mul(5, 5);
		int exp=25;
		assertEquals(ac,exp,"division is failed");
	}
	@Test
	void testmod() {
		
		int ac=ob.mod(5, 5);
		int exp=0;
		assertEquals(ac,exp,()->"modules is failed");
		assertThrows(ArithmeticException.class,()->Operations.div(5,0));
	}

}
