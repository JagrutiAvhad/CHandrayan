package junit5;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class arrTest {

	@Test
	void test() {
		ArrayDemo a=new ArrayDemo();
		int[] actual=a.arr();
		int[]exp= {1,2,3};
		assertArrayEquals(exp,actual,"test is running baba");
	}

}
