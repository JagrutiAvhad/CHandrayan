package junit5;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class addTest {

	@Test
	void test() {
		Hello h=new Hello();
		int expected=10;
		int ans=h.add(5, 5);
		assertEquals(expected,ans);
	}

}
