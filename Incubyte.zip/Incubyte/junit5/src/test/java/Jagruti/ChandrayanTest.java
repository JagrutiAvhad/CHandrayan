package Jagruti;

import static org.junit.jupiter.api.Assertions.*;
import java.util.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
//it is a testing code 
class ChandrayanTest {
    Scanner sc = new Scanner(System.in);
    Chandrayan ob;
    @BeforeEach
    void setUp() {
        ob = new Chandrayan();
    }

    @AfterEach
    void shut() {
        sc.close(); 
    }
//annotation test is used to test the method
    @Test
    void test() {
        int l = 0;
        System.out.println("Enter array length:");
        l = sc.nextInt();
        System.out.println("Enter array elements:");
        ArrayList<Character> list = new ArrayList<>();
        for (int i = 0; i < l; i++) {
            list.add(sc.next().charAt(0)); 
        }

        for (int i = 0; i < list.size(); i++) {
            if (list.get(i) == 'f') {
                ob.moveForward();
            } else if (list.get(i) == 'b') {
                ob.moveBackward();
            } else if (list.get(i) == 'r') {
                ob.turnRight();
            } else if (list.get(i) == 'l') {
                ob.turnLeft();
            } else if (list.get(i) == 'u') {
                ob.moveUp();
            } else if (list.get(i) == 'd') {
                ob.moveDown();
            }
        }
//the x,y,z values are taken and final direction
       int x = ob.getX();
        int y = ob.getY();
        int z = ob.getZ();
        int a, b, c;
        char fd;
        System.out.println("Enter expected x, y, z values");

        a = sc.nextInt();
        b = sc.nextInt();
        c = sc.nextInt();
        System.out.println("Enter expected final direction values (Ex: N,S,E,W)");
        String dir = sc.next();
        fd = dir.charAt(0);
//this check that expected and absolute values are same
        char finalDirection = ob.getDirection();
        System.out.println("Absolute coordinates and Direction is ");
        System.out.println("Coordinates: " + "(" + x + "," + y + "," + z + ")");
        System.out.println("Final Direction: " + finalDirection);
        assertEquals(x, a, "x condition fail");
        assertEquals(y, b, "y condition fail");
        assertEquals(z, c, "z condition fail");
        assertEquals(fd, finalDirection, "direction condition fail");
    }
}
