package Jagruti;

public class Chandrayan {
	//Inital coordinate x,y,z taken as 0 and direction as N
    private int x = 0;
    private int y = 0;
    private int z = 0;
    private char direction;
    
    public Chandrayan() {
        direction = 'N';
    }
//if command is f in array passed then this method will work and moves spacecraft one step ahead
    public void moveForward() {
        if (direction == 'N') {
            y++;
        } else if (direction == 'S') {
            y--;
        } else if (direction == 'E') {
            x++;
        } else if (direction == 'W') {
            x--;
        } else if (direction == 'U') {
            z++;
        } else if (direction == 'D') {
            z--;
        }
    }
  //if command is b in array passed then this method will work and moves spacecraft one step back
    public void moveBackward() {
        if (direction == 'N') {
            y--;
        } else if (direction == 'S') {
            y++;
        } else if (direction == 'E') {
            x--;
        } else if (direction == 'W') {
            x++;
        } else if (direction == 'U') {
            z--;
        } else if (direction == 'D') {
            z++;
        }
    }
//if command is u  it will set direction as U 
    public void moveUp() {
        direction = 'U';
    }
  //if command is d  it will set direction as D 
    public void moveDown() {
        direction = 'D';
    }
  //if command is r then it changes direction of  spacecraft to 90 deg right direction
    public void turnRight() {
        switch (direction) {
            case 'N':
                direction = 'E';
                break;
            case 'E':
                direction = 'S';
                break;
            case 'S':
                direction = 'W';
                break;
            case 'W':
                direction = 'N';
                break;
            case 'U':
                direction = 'S';
                break;
            case 'D':
                direction = 'S';
                break;
        }
    }
//if command is l then it changes direction of  spacecraft to 90 deg left direction
    public void turnLeft() {
        switch (direction) {
            case 'N':
                direction = 'W';
                break;
            case 'E':
                direction = 'N';
                break;
            case 'S':
                direction = 'E';
                break;
            case 'W':
                direction = 'S';
                break;
            case 'U':
                direction = 'N';
                break;
            case 'D':
                direction = 'N';
                break;
        }
    }
//function to get x value 
    public int getX() {
        return x;
    }
  //function to get Y value 
    public int getY() {
        return y;
    }
  //function to get Z value 
    public int getZ() {
        return z;
    }
  //function to get final direction 
    public char getDirection() {
        return direction;
    }

	
}
