package junit5;

public class Hello {
int add(int a,int b)
{
	return a+b;
}
}
