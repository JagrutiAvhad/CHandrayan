package junit5;

public class ArrayDemo {
public int[] arr()
{
	int x[]= {1,2,3};
	return x;
}
}
